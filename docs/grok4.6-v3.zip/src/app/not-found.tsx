import Link from "next/link";

export default function NotFound() {
  return (
    <main className="not-found">
      <p className="not-found-kicker">Still here. Just not this page.</p>
      <h1>This path wandered off.</h1>
      <p>
        The workspace is a single conversation surface. Whatever you were
        looking for, start from a blank page.
      </p>
      <Link href="/">Back to Kimi</Link>
    </main>
  );
}
