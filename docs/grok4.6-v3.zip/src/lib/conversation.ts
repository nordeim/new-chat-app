import type { ChatMessage } from "@/lib/types";

// Retrying an outstanding user turn (failed/partial stream) must not append
// a duplicate. The server persists the user message before streaming, so a
// matching trailing user turn is treated as the same send.
export function mergeUserTurn(
  existing: ChatMessage[],
  incoming: ChatMessage,
): ChatMessage[] {
  const last = existing.at(-1);
  if (
    last?.role === "user" &&
    last.content === incoming.content &&
    last.image === incoming.image
  ) {
    return existing;
  }
  return [...existing, incoming];
}
