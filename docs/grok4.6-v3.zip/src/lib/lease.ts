const SHORT_LEASE_MS = 195_000;
const LONG_LEASE_MS = 615_000;
const SHORT_TIMEOUT_MS = 175_000;
const LONG_TIMEOUT_MS = 590_000;
const SPACING_MS = 3_000;
const LONG_OUTPUT_TOKENS = 16_384;

export function isLongOutput(maxTokens: number) {
  return maxTokens > LONG_OUTPUT_TOKENS;
}

export function leaseDurationMs(maxTokens: number) {
  return isLongOutput(maxTokens) ? LONG_LEASE_MS : SHORT_LEASE_MS;
}

export function providerTimeoutMs(maxTokens: number) {
  return isLongOutput(maxTokens) ? LONG_TIMEOUT_MS : SHORT_TIMEOUT_MS;
}

export function requestSpacingMs() {
  return SPACING_MS;
}
