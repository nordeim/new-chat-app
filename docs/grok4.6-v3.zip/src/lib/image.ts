const MAX_IMAGE_BYTES = 2 * 1024 * 1024;
const PNG_MAGIC = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);

export function inspectImageDataUrl(dataUrl: string): { ok: boolean } {
  const comma = dataUrl.indexOf(",");
  if (comma < 0) return { ok: false };
  const header = dataUrl.slice(5, comma);
  const mime = header.slice(0, header.indexOf(";"));
  const payload = dataUrl.slice(comma + 1);
  if (!payload) return { ok: false };
  const bytes = Buffer.from(payload, "base64");
  if (bytes.length === 0 || bytes.length > MAX_IMAGE_BYTES) return { ok: false };
  const valid =
    mime === "image/png"
      ? bytes.subarray(0, 8).equals(PNG_MAGIC)
      : mime === "image/jpeg"
        ? bytes[0] === 255 && bytes[1] === 216 && bytes[2] === 255
        : mime === "image/webp"
          ? bytes.toString("ascii", 0, 4) === "RIFF" &&
            bytes.toString("ascii", 8, 12) === "WEBP"
          : false;
  return { ok: valid };
}
