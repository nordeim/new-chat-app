// `%`/`_`/`\` in the term are escaped so users search for literal text,
// not LIKE patterns. The wrapping `%` is the ILIKE contains match.
export function searchPattern(term: string) {
  return `%${term.replace(/[\\%_]/g, "\\$&")}%`;
}
