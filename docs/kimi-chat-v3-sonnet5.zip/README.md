# Kimi Workspace

A calm, mint-accented chat workspace with streamed NVIDIA responses, saved conversations, and image input — a clean Next.js/PostgreSQL starter.

Kimi Workspace pairs a Next.js App Router client with server-proxied NVIDIA NIM inference (`moonshotai/kimi-k3`, OpenAI-compatible streaming endpoint) and PostgreSQL/Drizzle persistence. Conversations are isolated by a secure browser-session cookie, responses stream token-by-token over SSE, and the interface stays out of the way: searchable history, prompt starters, model settings, and an image-aware composer.

## Features

| ✨ | Feature | Description |
|----|---------|-------------|
| 🌊 | Streamed responses | Token-by-token SSE from NVIDIA NIM with a thinking indicator, stop control, and truncation notice |
| 💾 | Saved conversations | Postgres-backed history grouped by day (Today / Yesterday / Previous 7 days / Older) with search across titles **and message content** (⌘K), rename, delete, and Markdown export |
| 🖼️ | Image-aware composer | PNG/JPEG/WebP attachments up to 2 MB, validated client-side and re-verified by magic bytes server-side; message images open in a full-size lightbox |
| 🎛️ | Model settings | Temperature, output-token limit, and reasoning-effort controls per message |
| 📝 | Rich answers | GitHub-Flavored Markdown with mint-themed syntax highlighting and one-click code-block copy |
| 🔒 | Session isolation | HTTP-only, SameSite=Strict cookie; only its SHA-256 digest is stored as the database owner |
| 🛡️ | Hardened API | Same-origin writes, bounded bodies, zod-validated payloads, atomic one-generation-per-session lease |
| 🧹 | Retention CLI | `npm run prune` removes idle sessions (cascade) and optionally stale conversations, with a structured log line |
| ♿ | Accessible UI | WCAG 2.2 AA verified with automated axe checks, keyboard operable, visible focus states |

## Architecture

| Layer | Technology | Purpose |
|-------|------------|---------|
| UI | Next.js (App Router) + React 19 | Single client component workspace, server route handlers |
| Language | TypeScript (strict) | End-to-end typed contracts, zero `any` |
| Styling | Tailwind CSS 4 (CSS-first) | Mint design tokens in `globals.css` + `workspace-polish.css` |
| Validation | zod | Shared client/server schemas |
| Data | Drizzle ORM + `pg` | Parameterized queries, JSONB message storage, versioned migrations in `drizzle/` |
| Database | PostgreSQL | Sessions, conversations |
| AI | NVIDIA NIM (OpenAI-compatible) | `moonshotai/kimi-k3` streaming completions |
| Testing | node:test · Playwright · axe | Unit, API-isolation, browser E2E + WCAG checks |

```mermaid
flowchart LR
    Browser["Browser workspace"] -- "POST /api/chat (SSE)" --> Route["chat route handler"]
    Route -- "origin + session + lease" --> Guard["validation & limits"]
    Guard -- "OpenAI-compatible stream" --> NVIDIA["NVIDIA NIM · kimi-k3"]
    NVIDIA -- "SSE chunks" --> Route
    Route -- "meta/thinking/delta/done/error" --> Browser
    Route -- "persist final answer" --> PG[("PostgreSQL · Drizzle")]
```

### File hierarchy

```text
📂 drizzle                        # versioned SQL migrations (generate → migrate)
📂 src
├── 📂 app
│   ├── 📂 api
│   │   ├── 📂 chat                 # 📄 route.ts — SSE streaming proxy to NVIDIA
│   │   ├── 📂 conversations        # 📄 route.ts — list; 📂 [id] — read/rename/delete
│   │   └── 📂 health               # 📄 route.ts — DB connectivity probe
│   ├── 📄 layout.tsx               # Root layout + metadata
│   └── 📄 page.tsx                 # Renders the workspace
├── 📂 components
│   ├── 📄 chat-workspace.tsx       # The workspace shell (composer, dialogs, sidebar)
│   ├── 📄 markdown-message.tsx     # Memoized GFM + syntax-highlighted renderer with code copy
│   ├── 📄 image-lightbox.tsx       # Radix full-size image preview
│   └── 📄 navigation-frame.tsx     # Radix mobile navigation drawer
├── 📂 db
│   ├── 📄 index.ts                 # pg Pool + Drizzle instance
│   ├── 📄 schema.ts                # sessions & conversations tables
│   └── 📄 seed.ts                  # idempotent local-dev seed
└── 📂 lib
    ├── 📄 server.ts                # Cookie session, origin guard, bounded body reader
    ├── 📄 validation.ts            # All zod schemas
    ├── 📄 sse.ts                   # SSE parser (shared by server and browser)
    ├── 📄 history.ts               # Sidebar date grouping + relative timestamps
    ├── 📄 markdown.ts              # Markdown node-text extraction (code copy)
    ├── 📄 workspace-error.ts       # Load-failure copy (DB outage vs reload)
    └── 📄 types.ts                 # Shared types + default model settings
```

## Quick Start

Requirements: **Node.js ≥ 22** and a **PostgreSQL** database.

1. Install and configure:

   ```bash
   npm ci
   cp .env.example .env        # then edit .env
   ```

2. Apply the schema and start:

   ```bash
   npm run db:migrate   # production-safe, journal-driven (or: npx drizzle-kit push for prototyping)
   npm run dev
   ```

   Schema changes: edit `src/db/schema.ts`, then `npm run db:generate` to create `drizzle/*.sql` and commit the migration. Seed a fresh DB with `npm run db:seed` (idempotent, local-only).

3. Verify setup:

   - `http://localhost:3000` shows the mint workspace with prompt starters.
   - `curl http://localhost:3000/api/health` returns `{"ok":true}`.
   - Without `NVIDIA_API_KEY`, sending a message shows the "Connect NVIDIA…" guidance and keeps your draft — by design.

### Environment Variables

| Variable | Required | Purpose |
|----------|----------|---------|
| `DATABASE_URL` | ✅ | PostgreSQL connection string, e.g. `postgresql://user:pass@host:5432/db` |
| `NVIDIA_API_KEY` | For chat | Server-only key from [build.nvidia.com](https://build.nvidia.com). Never use a `NEXT_PUBLIC_` variable |
| `TEST_BASE_URL` | No | Playwright target origin (default `http://localhost:3000`) |
| `LIVE_SITE_URL` | No | Target for the live-deployment E2E suite (skipped when unset) |

## NVIDIA contract

- Endpoint: `https://integrate.api.nvidia.com/v1/chat/completions`, model `moonshotai/kimi-k3`, streaming via `Accept: text/event-stream`.
- Bearer authorization is sent only by the server; the key never reaches the browser.
- Defaults: temperature 1, `max_tokens` 16,384 (selectable up to 256,000), reasoning effort `max`.
- Image attachments use OpenAI-compatible `image_url` content blocks with inline PNG/JPEG/WebP data.
- Provider reasoning is preserved in server-side history for multi-turn requests but never exposed to the browser; the UI shows a thinking status, then the answer.
- Malformed, incomplete, oversized, and failed streams produce explicit errors; failed partial answers are not persisted, and retrying the same outstanding message does not append a duplicate user turn.
- Without `NVIDIA_API_KEY` the chat endpoint returns a 503 with actionable copy and the draft is preserved client-side — this path is covered by both unit and browser E2E tests.

References: [NVIDIA model page](https://build.nvidia.com/moonshotai/kimi-k3) · [API reference](https://docs.api.nvidia.com/nim/reference/moonshotai-kimi-k3)

## API reference

| Endpoint | Method | Auth | Description |
|----------|--------|------|-------------|
| `/api/chat` | POST | Session cookie + same-origin | SSE stream: `meta`, `thinking`, `delta`, `done`, `error` events |
| `/api/conversations` | GET | Session cookie (sets one) | List up to 100 conversations + `configured` flag; optional `?q=` filters server-side by title and message content (case-insensitive, owner-isolated) |
| `/api/conversations/[id]` | GET | Session cookie | Full conversation with messages (reasoning stripped) |
| `/api/conversations/[id]` | PATCH | Session cookie + same-origin | Rename (1–100 characters) |
| `/api/conversations/[id]` | DELETE | Session cookie + same-origin | Delete; refuses (409) while a response is streaming |
| `/api/health` | GET | Public | PostgreSQL connectivity probe |

## Data and security boundaries

This is a **browser-session workspace, not an enterprise identity system**. A random 256-bit HTTP-only, SameSite=Strict cookie identifies a workspace; only its SHA-256 digest is stored as the database owner identifier. Cookies use `Secure` when served over HTTPS. Clearing the cookie loses workspace access. Deploy only behind trusted HTTPS ingress that preserves the public Host (or forwards it as `x-forwarded-host`, the Cloudflare/nginx convention — same-origin writes match against both) and does not expose an untrusted proxy-header path.

Every conversation read and mutation checks ownership. Writes require a same-origin `Origin` header. Drizzle supplies parameterized queries. Model-generated Markdown cannot execute raw HTML; remote model-generated images are not automatically fetched. Logs use operation names, request/conversation identifiers, and error types — not message contents or API keys.

Conversation text, images, and provider reasoning are stored in PostgreSQL, and prompts are sent to NVIDIA for inference. Deletion cascades to the conversation's inline data; it cannot revoke data previously processed by the provider. Configure encryption at rest and vendor retention terms appropriate to your organization.

Limits: 100 conversations per workspace, 60 persisted messages per conversation, 16,000 characters per submitted prompt, 3 MB request body, ~16 MB existing history, and 1,200,000 response characters (includes thinking + answer). One generation per session is enforced by an atomic database lease (195s; 615s for `max_tokens > 16,384`) with a 3-second spacing; provider requests time out after 175s (590s for large outputs) and the route allows up to 600s (`maxDuration`). No automatic inference retries are used, avoiding duplicate billing and ambiguous persisted turns; users can retry explicitly.

### Before public or enterprise deployment

- Add organizational authentication/SSO with durable user ownership, account recovery, and role-based authorization.
- Add ingress-level IP/account rate limiting, global provider-spend quotas, and abuse prevention. Browser-session limits can be bypassed by creating fresh sessions and are not a public-service billing defense.
- Add a retention schedule and run `npm run prune -- --idle-days 30 [--conversation-days 90]` periodically (e.g. weekly cron); it deletes idle sessions with their conversations and logs a structured summary. Cookie expiry alone does not delete database data.
- Configure backups, least-privilege database credentials, TLS, encryption at rest, operational monitoring, incident response, and secret rotation.
- If deploying behind Cloudflare (or any CDN) with an auto-injected analytics/beacon script, either disable that injection or extend `script-src` explicitly in `next.config.ts` — do not broaden CSP to `'unsafe-inline'` scopes beyond what is documented there.
- Validate actual model availability, streaming behavior, image inference, cancellation, long responses, and multi-turn reasoning with your NVIDIA account.
- Conduct keyboard/screen-reader and broader browser testing; automated WCAG checks are not a complete accessibility certification.

## Testing

```bash
npm test                                   # unit: schemas, SSE parser, history grouping, load-failure copy (node:test)
npm run db:migrate                         # apply migrations (or db:generate first if schema changed)
npm run build && npm start                 # required for E2E
npx playwright install chromium            # one-time browser download for local E2E
npm run test:e2e                           # Playwright: UI, API isolation, WCAG, streaming fixtures
LIVE_SITE_URL=https://your-deployment.example npx playwright test tests/live-site.spec.ts
npm audit --omit=dev                       # production dependency audit
```

E2E prerequisites: a disposable test `DATABASE_URL` (fixtures are inserted and cleaned up), **no** `NVIDIA_API_KEY` (the missing-key UX is part of the spec), and `TEST_BASE_URL` for non-default origins. The streamed-answer, code-copy, lightbox, stop-control, malformed-frame, and degraded-API tests use explicit transport fixtures and run hermetically; the GFM-table test additionally routes both API endpoints, so it runs without a database. `tests/live-site.spec.ts` is skipped entirely unless `LIVE_SITE_URL` is set and exercises a real deployment (read-only except one minimal chat send when the provider is configured).

`GET /api/health` checks PostgreSQL connectivity; it does not call the provider or validate its credential.

## Verification ledger (this environment)

| Check | Command | Result |
|-------|---------|--------|
| Type generation | `npx next typegen` | ✅ pass |
| Type safety | `tsc --noEmit` (strict, zero `any`/`@ts-ignore`) | ✅ pass |
| Lint | `npm run lint` (flat config, next core-web-vitals) | ✅ 0 problems |
| Unit tests | `npm test` (node:test) | ✅ 41/41 |
| Production build | `npm run build` | ✅ 6 routes compile |
| Local browser E2E | `npx playwright test` (chromium) | ✅ 32/32 (workspace, stream-UI, recovery, network-recovery — incl. axe WCAG AA) |
| `npm run build_and_start` smoke | health probe + functional curl checks | ✅ `{"ok":true}`; 503 missing-key path; 403 cross-origin guard; 400 invalid UUID all verified |
| Dependency audit (prod) | `npm audit --omit=dev` | ✅ 0 vulnerabilities |
| Live-site browser E2E | `LIVE_SITE_URL=… npx playwright test tests/live-site.spec.ts` | ⚠️ 10/11 (excl. provider round-trip) — see note below |

**Live-deployment note (`https://kimi-chat.jesspete.shop/`):** the deployment's console-error check fails because Cloudflare injects a Web Analytics beacon (`static.cloudflareinsights.com/beacon.min.js`) that the app's strict CSP (`script-src 'self' 'unsafe-inline'`) correctly blocks — this is the CSP doing its job against a third-party script the app never requested; the fix is a Cloudflare zone setting (disable the auto-injected beacon), not an app code or CSP change. The provider round-trip test is skipped/expected-to-fail because the deployment's `NVIDIA_API_KEY` is rejected by NVIDIA (dead key, pending operator rotation) — the missing/invalid-key path itself (503 + curated banner) is verified working both locally and live.
