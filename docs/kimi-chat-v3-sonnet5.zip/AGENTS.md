# AGENTS.md

Instructions for AI coding agents working in this repository. Every line answers: "would an agent likely miss this without help?"

## What this is

Next.js 16 (App Router) chat workspace "Kimi" — streamed NVIDIA NIM responses (`moonshotai/kimi-k3`, OpenAI-compatible SSE), PostgreSQL persistence via Drizzle ORM, browser-session cookie isolation. React 19, Tailwind v4 (CSS-first), TypeScript strict.

## Commands

| Task | Command |
|------|---------|
| Install (use ci, not install) | `npm ci` |
| Dev server | `npm run dev` |
| Production build | `npm run build` |
| Lint | `npm run lint` |
| Typecheck (runs typegen first) | `npm run typecheck` |
| Unit tests (node:test, strip-types) | `npm test` |
| Single unit test file | `node --experimental-strip-types --test tests/core.test.mjs` |
| E2E / API tests (needs running server + `npx playwright install chromium` once) | `npm run test:e2e` |
| Live-deployment E2E (skipped unless `LIVE_SITE_URL` is set) | `LIVE_SITE_URL=https://host npx playwright test tests/live-site.spec.ts` |
| Prune idle sessions / stale conversations | `npm run prune -- --idle-days 30 [--conversation-days 90]` |
| Generate SQL migration from schema | `npm run db:generate` |
| Apply SQL migrations (production-safe) | `npm run db:migrate` |
| Seed a fresh database (idempotent) | `npm run db:seed` |
| Migrate + seed in one (cold-start) | `npm run db:setup` |
| Apply schema to dev database (prototyping, needs a TTY) | `npx drizzle-kit push` |

Verification order: `npm run typecheck` → `npm run lint` → `npm test` → `npm run build` → `npm run test:e2e`.

## Environment

- Node.js ≥ 22 (unit tests rely on `--experimental-strip-types`), PostgreSQL required.
- `src/db/index.ts` throws at import time if `DATABASE_URL` is unset — every API route touches the database, so nothing runs without it.
- `NVIDIA_API_KEY` is server-only. Never use a `NEXT_PUBLIC_` variable for it. Missing key returns HTTP 503 with a user-facing message; this path is tested on purpose. This sandbox has no key configured, so chat runs in "not configured" mode by design.
- `drizzle.config.ts` reads `DATABASE_URL` from the environment (via `dotenv/config`). For one-off pushes against another URL, use `npx drizzle-kit push --url="$DATABASE_URL"`. `drizzle-kit push` requires an interactive TTY for confirmation prompts; prefer `npm run db:migrate` (journal-driven, non-interactive) in automated/agent contexts.
- Playwright E2E tests require the production preview running (`npm run build && npm start`, or reuse the platform-managed server on `:3000`), a disposable `DATABASE_URL` (tests insert/delete fixtures), and no `NVIDIA_API_KEY` by design. `TEST_BASE_URL` overrides `http://localhost:3000`. Chromium must be installed once per sandbox: `npx playwright install chromium` (add `sudo npx playwright install-deps chromium` if shared libraries like `libnspr4`/`libnss3` are missing).

## Architecture map

- `src/app/api/chat/route.ts` — the core: origin check → session → zod validation → image magic-byte check → atomic session lease (one generation per workspace, 3 s spacing, 195 s expiry; 615 s for `max_tokens > 16,384`) → conversation upsert with duplicate-retry guard → NVIDIA fetch with SSE parse (timeout 175 s; 590 s for large outputs, `maxDuration 600`) → persistence of final answer only → SSE to browser.
- `src/app/api/conversations/` — list / search / read / rename / delete. The list endpoint accepts `?q=` (server-side ILIKE over title and JSONB message content, owner-filtered, wildcard-escaped). Every query filters by `owner`; delete uses a transaction with `FOR UPDATE` on the session row so it cannot race a running generation.
- `src/lib/origin.ts` — pure same-origin gate shared by every write endpoint: accepts the origin when it matches `Host` OR the first `x-forwarded-host` value (trusted-ingress convention); rejects `sec-fetch-site: cross-site`, malformed origins, and non-http(s) schemes. Kept free of Next/DB imports so the unit suite can run it anywhere.
- `src/lib/server.ts` — cookie session (`kimi_session`, 64-hex token; only the SHA-256 digest is stored as `owner`), `assertOrigin` (same-origin writes), bounded `readJson` (3 MB), `errorResponse` (structured logs without PII).
- `src/lib/retention.ts` — pure prune functions taking `(db, tables, options)` positionally (no relative runtime imports so the node type-stripping CLI can load them). `scripts/prune-expired.mjs` is the CLI wrapper (`npm run prune`).
- `src/db/seed.ts` + `scripts/seed.mjs` — idempotent local-dev seed (no PII, safe to re-run).
- `scripts/migrate.mjs` + `scripts/db-setup.mjs` — wrappers for `db:migrate` / `db:setup`. Preflight `DATABASE_URL` + `select 1` with curated JSON errors.
- `src/lib/validation.ts` — all zod schemas, shared by server and unit tests.
- `src/lib/sse.ts` — SSE parser handling LF/CRLF/CR separators, events split across network chunks, and multi-line data with incremental size limits; used by BOTH the API route and the browser client. Changes affect both sides.
- `src/components/chat-workspace.tsx` — the workspace shell (composer, dialogs, sidebar, streaming state machine). Client-side zod schemas validate every API and stream payload; `WorkspaceRequestError` marks intentional, user-facing copy — only it is shown verbatim.
- `src/components/markdown-message.tsx` — memoized GFM + `rehype-highlight` renderer with a per-block copy control.
- `src/components/image-lightbox.tsx` — Radix full-size image preview (focus trap, Escape, focus restore).
- `src/lib/title.ts` — pure `deriveTitle(content)`; used by the chat route's insert path.
- `src/lib/history.ts` — pure sidebar grouping (`Today/Yesterday/Previous 7 days/Older`) + relative timestamps.
- `src/lib/workspace-error.ts` — maps a `/api/health` probe result to load-failure copy (DB outage vs reload).
- `src/components/navigation-frame.tsx` — wraps the sidebar in a Radix dialog while the mobile drawer is open.
- `src/db/schema.ts` — Drizzle schema. `messages` is JSONB on `conversations`; cascade delete via session FK.

## Non-obvious rules

- `layout.tsx` imports `globals.css` first, then `workspace-polish.css` (the editorial mint layer: tokens override, position-only welcome animation, and the bloom-mark emblem). Keep the import order.
- The error banner shows a message verbatim only when it is a `WorkspaceRequestError`. Raw `Error`s from fetch rejection render generic connection-interrupted copy. When adding curated copy, throw `WorkspaceRequestError`, not `Error`.
- Never assert against unscoped `getByRole("alert")` in Playwright tests: Next.js injects a global route announcer with `role=alert` that is always present and empty. Target `.error-banner` instead.
- Client disconnects during streaming are expected teardown, not errors (`src/lib/stream-abort.ts` classifies them at warn level). Do not persist partial answers; do not treat warn lines as defects.
- UI copy limits say "up to 2 MB" for images (the check allows exactly 2 MB) — keep client, server, and schema copy identical.
- Error messages returned to clients are user-facing copy (specific, actionable). Do not replace them with generic text or leak provider internals.
- Logs are structured JSON with `operation`, ids, and error types only — never message contents, cookies, or keys.
- Provider reasoning (`reasoning_content`) is persisted for multi-turn context but stripped from every browser response.
- Limits are enforced server-side (60 messages/conversation, 100 conversations/workspace, 16k chars, 2 MB image, 1,200k response chars up to 256k tokens); the client mirrors some of them but the server is the authority.
- There is no `tailwind.config.js`; Tailwind v4 is wired through PostCSS and design tokens live in `src/app/globals.css` (`--mint` palette).
- Do not weaken gates to make them pass (no `@ts-ignore`, no disabling rules, no deleting tests). Fix root causes.
- If deployed behind a CDN/ingress that injects its own scripts (e.g. Cloudflare Web Analytics beacon), the strict CSP (`script-src 'self' 'unsafe-inline'`) will correctly block it — that is a zone/ingress configuration decision for the operator, not a reason to broaden the CSP in code.
- Deployments behind TLS ingress must preserve the public `Host` or forward it as `x-forwarded-host` (Cloudflare/nginx do); otherwise the same-origin gate rejects browser writes with 403.
- `scripts/` holds operational CLI scripts (`.mjs` with explicit `.ts` import extensions — Node type-stripping requires extensions and does not resolve `@/` aliases).
